It is just a test file.
permission needs to be changed with chmod for use (ex : chmod 777 install.sh)
